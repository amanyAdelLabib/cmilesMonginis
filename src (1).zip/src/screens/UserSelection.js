import React from 'react';
import {Text, View, StyleSheet, TouchableOpacity} from 'react-native';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';

export const UserSelection = ({onSelect}) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => onSelect('existing')}
        style={styles.button}>
        <Text style={styles.btnTitle}>Existing Customer</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => onSelect('new')} style={styles.button}>
        <Text style={styles.btnTitle}>New Customer</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    width: responsiveWidth(25),
    height: responsiveHeight(25),
    backgroundColor: '#44BC96',
    marginHorizontal: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
  },
});
