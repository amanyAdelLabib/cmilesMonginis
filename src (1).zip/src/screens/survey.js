import {
  FlatList,
  Image,
  Keyboard,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {Component} from 'react';
import {
  responsiveFontSize,
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import LottieView from 'lottie-react-native';
import {connect} from 'react-redux';
import {Button} from 'react-native-elements';

import {commentChanged, getQuestions, postSurvey} from '../actions';
import Textarea from 'react-native-textarea';
import PhoneModal from '../components/PhoneModal';
import {UserSelection} from './UserSelection';
import { hideNavigationBar } from 'react-native-navigation-bar-color';

class Survey extends Component {
  constructor(props) {
    super(props);
    this.testArr = [];
    this.interval = null;
    this.state = {
      counter: 0,
      showSubmitBtn: false,
      answers: [],
      commentSurveyState: '',
      counterInterval: 0,
      QuestionsList: [],
      showPhoneModal: false,
      askedPhone: false,
      phone: '',
      customerType: null,
      // widthScreen:useWindowDimensions().width
    };
  }

  componentDidMount() {
    hideNavigationBar();
    console.log('new url ' + JSON.parse(this.props.secretUrl));
    this.props.getQuestions({
      secret: JSON.parse(this.props.secretKey),
      url: JSON.parse(this.props.secretUrl),
    });

    console.log(this.state.answers);
    clearInterval(this.interval);
    this.setState({
      counterInterval: 0,
    });
  }

  componentWillUnmount() {
    // if(this.interval)
    // clearInterval(this.interval)
    clearInterval(this.interval);
    this.setState({
      counter: 0,
      showSubmitBtn: false,
      answers: [],
      commentSurveyState: '',
      counterInterval: 0,
    });
  }

  componentWillReceiveProps(nextProps) {
    // console.log('fail post  mount' + nextProps.failPost);
    // console.log('success post  mount' + nextProps.successPost);
    // this.props.navigation.navigate('Result');
    if (nextProps.getQues !== this.state.QuestionsList) {
      this.setState({
        QuestionsList: nextProps.getQues,
      });
    }
  }

  onCommentChange(text) {
    console.log(text);

    this.props.commentChanged(text);
  }

  renderPoweredBy = () => {
    return (
      <View
        style={{
          position: 'absolute',
          alignSelf: 'center',
          flex: 1,
          bottom: 10,
        }}>
        <Text
          style={{
            fontSize: responsiveFontSize(1.5),
            marginTop: responsiveHeight(18),
            fontFamily: 'Roboto-Regular',
            textAlign: 'center',
            color: '#808080',
          }}>
          Powered by AHT Analytics
        </Text>
      </View>
    );
  };

  renderItem = (item, index, arrLength) => {
    {
      this.splitArr = item.text.split('\r\n');
    }

    return (
      <View>
        {index == this.state.counter ? (
          <View>
            {this.splitArr.length == 1 ? (
              <View>
                <Text style={styles.questionText}>{this.splitArr[0]}</Text>
              </View>
            ) : (
              <View>
                <Text style={styles.questionText1}>{this.splitArr[0]}</Text>
                <Text style={styles.questionText2}>{this.splitArr[1]}</Text>
              </View>
            )}

            {/* <HTML source={{ html:  `
                  <h1>This HTML snippet is now rendered with native components !</h1>
                  <h2>Enjoy a webview-free and blazing fast application</h2>

              ` }} /> */}
            <View style={styles.answersContainer}>
              <TouchableOpacity
                onPress={() => {
                  console.log('_______________sad');
                  // console.log(arrLength);
                  // console.log(this.state.counter);
                  // console.log(index);
                  this.testArr.push({[item.id]: 'Angry'});
                  this.setState({showPhoneModal: true});
                  if (this.state.counter == arrLength - 1) {
                    this.setState(
                      {
                        showSubmitBtn: true,
                        answers: this.testArr,
                        counterInterval: 0,
                      },
                      function () {
                        console.log(this.state.answers);
                        // clearInterval(this.interval);
                      },
                    );
                  } else {
                    this.setState({
                      counter: this.state.counter + 1,
                    });
                    // clearInterval(this.interval);

                    // console.log('state answer');
                    // console.log(this.state.answers);
                    // console.log('testarr');
                    // console.log(this.testArr);
                  }
                }}>
                <Image
                  style={styles.surveyImg}
                  source={require('../assets/icons/sad-6.png')}
                />
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  console.log(arrLength);
                  console.log(this.state.counter);
                  console.log(index);
                  this.testArr.push({[item.id]: 'Upset'});

                  if (this.state.counter == arrLength - 1) {
                    this.setState(
                      {
                        showSubmitBtn: true,
                        answers: this.testArr,
                      },
                      function () {
                        console.log(this.state.answers);
                      },
                    );
                  } else {
                    this.setState({
                      counter: this.state.counter + 1,
                    });
                    console.log('state answer');
                    console.log(this.state.answers);
                    console.log('testarr');
                    console.log(this.testArr);
                  }
                }}>
                <Image
                  style={styles.surveyImg}
                  source={require('../assets/icons/neutral-6.png')}
                />
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  console.log(arrLength);
                  console.log(this.state.counter);
                  console.log(index);
                  this.testArr.push({[item.id]: 'Satisfied'});

                  if (this.state.counter == arrLength - 1) {
                    this.setState(
                      {
                        showSubmitBtn: true,
                        answers: this.testArr,
                      },
                      function () {
                        console.log(this.state.answers);
                      },
                    );
                  } else {
                    this.setState({
                      counter: this.state.counter + 1,
                    });
                    console.log('state answer');
                    console.log(this.state.answers);
                    console.log('testarr');
                    console.log(this.testArr);
                  }
                }}>
                <Image
                  style={styles.surveyImg}
                  source={require('../assets/icons/smile-6.png')}
                />
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  console.log(arrLength);
                  console.log(this.state.counter);
                  console.log(index);
                  this.testArr.push({[item.id]: 'Happy'});

                  if (this.state.counter == arrLength - 1) {
                    this.setState(
                      {
                        showSubmitBtn: true,
                        answers: this.testArr,
                      },
                      function () {
                        console.log(this.state.answers);
                      },
                    );
                  } else {
                    this.setState({
                      counter: this.state.counter + 1,
                    });
                    console.log('state answer');
                    console.log(this.state.answers);
                    console.log('testarr');
                    console.log(this.testArr);
                  }
                }}>
                <Image
                  style={styles.surveyImg}
                  source={require('../assets/icons/grinning-6.png')}
                />
              </TouchableOpacity>
            </View>
          </View>
        ) : null}
      </View>
    );
  };

  content = () => {
    if (this.props.getQues?.length !== 0) {
      return (
        <>
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => {
              Keyboard.dismiss(0);
            }}>
            <View
              style={styles.mainContainer}
              onTouchStart={() => {
                this.setState(
                  {
                    counterInterval: 0,
                  },
                  function () {
                    this.interval = setInterval(() => {
                      console.log(this.state.counterInterval);

                      console.log('This will run every second! in survey');

                      if (this.state.counterInterval > 39) {
                        console.log('grater than 40');
                        console.log(this.state.counterInterval);

                        this.setState({counterInterval: 0}, function () {
                          clearInterval(this.interval);
                          this.props.postSurvey({
                            secret: JSON.parse(this.props.secretKey),
                            comment: this.props.commentSurvey,
                            phone: this.state.phone,
                            customerType: this.state.customerType,
                            answers: this.testArr,
                            url: JSON.parse(this.props.secretUrl),
                          });
                          clearInterval(this.interval);
                          this.testArr = [];
                          this.setState({
                            counter: 0,
                            showSubmitBtn: false,
                            answers: [],
                            commentSurveyState: '',
                            counterInterval: 0,
                            showPhoneModal: false,
                            askedPhone: false,
                            phone: '',
                            customerType: null,
                          });
                          // this.props.getQuestions({
                          //   "secret": JSON.parse(this.props.secretKey),
                          //   "url":JSON.parse(this.props.secretUrl)
                          //
                          // });
                          this.props.navigation.navigate('Result');
                        });
                      } else {
                        this.setState({
                          counterInterval: this.state.counterInterval + 1,
                        });
                      }
                    }, 1000);
                  },
                );
                clearInterval(this.interval);
              }}>
              {this.state.showSubmitBtn ? (
                <View style={styles.bodyContainerSubmit}>
                  <Text style={styles.commentLabel}>
                    Leave your phone number/comment
                    <Text style={styles.optionalText}> ( Optional )</Text>
                  </Text>
                  <Textarea
                    containerStyle={styles.textareaContainer}
                    style={styles.textarea}
                    onChangeText={this.onCommentChange.bind(this)}
                    defaultValue={this.state.commentSurveyState}
                    maxLength={200}
                    placeholder={'Submit a comment'}
                    placeholderTextColor={'#c7c7c7'}
                    underlineColorAndroid={'transparent'}
                    onSubmitEditing={Keyboard.dismiss}
                    returnKeyType="done"
                  />
                  <Button
                    title="Submit"
                    onPress={() => {
                      this.props.postSurvey({
                        secret: JSON.parse(this.props.secretKey),
                        comment: this.props.commentSurvey,
                        phone: this.state.phone,
                        answers: this.state.answers,
                        url: JSON.parse(this.props.secretUrl),
                        customerType: this.state.customerType,
                      });
                      clearInterval(this.interval);
                      this.testArr = [];
                      this.setState({
                        counter: 0,
                        showSubmitBtn: false,
                        answers: [],
                        commentSurveyState: '',
                        counterInterval: 0,
                        showPhoneModal: false,
                        askedPhone: false,
                        phone: '',
                        customerType: null,
                      });
                      // this.props.getQuestions({
                      //   secret: JSON.parse(this.props.secretKey),
                      //   url: JSON.parse(this.props.secretUrl),
                      // });
                      this.props.navigation.navigate('Result');
                    }}
                    titleStyle={styles.titleSubmitBtn}
                    buttonStyle={styles.submitBtn}
                  />
                </View>
              ) : (
                <View>
                  <FlatList
                    data={this.props.getQues}
                    renderItem={({item, index}) =>
                      this.renderItem(item, index, this.props.getQues.length)
                    }
                    keyExtractor={(item) => item.id}
                  />
                </View>
              )}
            </View>
          </TouchableOpacity>
        </>
      );
    } else {
      return (
        <>
          <View
            style={{
              width: '100%',
              height: '85%',
              marginVertical: responsiveHeight(5),
              paddingHorizontal: responsiveHeight(0.5),
            }}>
            <LottieView
              source={require('../assets/lottie/7675-loading.json')}
              autoPlay
              loop
              style={{
                position: 'absolute',
                top: 0,
                width: '100%',
                height: '85%',
              }}
            />
          </View>
        </>
      );
    }
  };

  render() {
    const {showPhoneModal, askedPhone, phone, customerType} = this.state;
    return (
      <View style={{flex: 1}}>
        {!customerType === null ? (
          <UserSelection
            onSelect={(type) => {
              this.setState({
                customerType: type,
              });
            }}
          />
        ) : (
          this.content()
        )}
        {this.renderPoweredBy()}
        <PhoneModal
          phone={phone}
          visible={showPhoneModal && !askedPhone}
          onSubmit={(value) =>
            this.setState({
              askedPhone: true,
              phone: value,
              showPhoneModal: false,
            })
          }
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  mainContainer: {
    marginHorizontal: responsiveWidth(4),
    marginVertical: responsiveHeight(3),
  },
  bodyContainerSubmit: {
    marginHorizontal: responsiveWidth(5),
    marginVertical: responsiveHeight(20),
  },
  commentLabel: {
    fontSize: responsiveFontSize(2.5),
    marginBottom: responsiveHeight(0.8),
    fontFamily: 'Roboto-Regular',
  },
  titleSubmitBtn: {
    fontSize: responsiveFontSize(2),
    paddingHorizontal: responsiveWidth(0.5),
    paddingVertical: responsiveHeight(1),
  },
  submitBtn: {
    backgroundColor: '#00A834',
    borderRadius: 30,
    width: responsiveWidth(23),
    marginHorizontal: responsiveWidth(30),
    marginTop: responsiveHeight(5),
  },
  questionText: {
    fontSize: responsiveFontSize(3),
    marginTop: responsiveHeight(18),
    fontFamily: 'Roboto-Regular',
    textAlign: 'center',
  },
  questionText1: {
    fontSize: responsiveFontSize(3),
    marginTop: responsiveHeight(12),
    fontFamily: 'Roboto-Regular',
    textAlign: 'center',
  },
  questionText2: {
    fontSize: responsiveFontSize(3),
    marginTop: responsiveHeight(4),
    fontFamily: 'Roboto-Regular',
    textAlign: 'center',
  },
  answersContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: responsiveHeight(15),
  },
  surveyImg: {
    width: Platform.OS == 'ios' ? responsiveWidth(19) : responsiveWidth(17),
    height: Platform.OS == 'ios' ? responsiveWidth(19) : responsiveHeight(29.8),
    borderRadius: 110,
  },
  textareaContainer: {
    height: responsiveHeight(35),
    padding: '3%',
    backgroundColor: '#F5FCFF',
    borderColor: '#00A834',
    borderWidth: 3,
    borderRadius: 15,
  },
  textarea: {
    textAlignVertical: 'top', // hack android
    height: responsiveHeight(20),
    fontSize: responsiveFontSize(1.5),
    color: '#333',
  },
  optionalText: {
    fontSize: responsiveFontSize(2),
    marginBottom: responsiveHeight(0.8),
    fontFamily: 'Roboto-Regular',
    color: '#cccccc',
  },
});

const mapStateToProps = (state) => {
  return {
    secretKey: state.auth.secretKey,
    secretUrl: state.auth.secretUrl,
    getQues: state.survey.getQuestions,
    commentSurvey: state.survey.comment,
    loadingGetQuestions: state.survey.loadingGetQuestions,
    failPost: state.survey.failPostSurvey,
    successPost: state.survey.successPostSurvey,
  };
};

const SurveyRedux = connect(mapStateToProps, {
  getQuestions,
  commentChanged,
  postSurvey,
})(Survey);
export {SurveyRedux as Survey};
