import {combineReducers} from 'redux';
import Auth from './authReducer';
import Survey from './surveyReducer';
export default {
  auth: Auth,
  survey: Survey,
};
